# CardápioJá

Aplicativo de Cardápio Digital com Painel de Administração, Integração Stripe para cobrança e QR Code.

Feito para Web e Android.